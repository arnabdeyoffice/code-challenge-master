package com.shutterfly.codetest.analytics;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.shutterfly.codetest.entity.*;

public class IngestFunctions {
	
	static HashMap <String, Customer> cust = null;
	
	public static void upsertCustomer (JSONObject js1)	{
		
		String key = (String) js1.get("key");
		String event_time = (String) js1.get("event_time");
		String last_name = (String) js1.get("last_name");
		String adr_city = (String) js1.get("adr_city");
		String adr_state = (String) js1.get("adr_state");
		String verb = (String) js1.get("verb");
		
		if (verb.equals("UPDATE") && !cust.containsKey(key))	{
			System.out.println ("Rejecting Update Record Key : " + key);
		}
		
		if (cust.containsKey(key))	{
			cust.get(key).update (key,event_time,last_name,adr_city,adr_state);
		}	else	{
			Customer c = new Customer (key,event_time,last_name,adr_city,adr_state);
			cust.put (key, c);
		}
	}
	
	public static void insertSiteVisit (JSONObject js1)	{
		String customer_id = (String) js1.get("customer_id");
		Customer c = cust.get(customer_id);
		String key = (String) js1.get("key");
		String event_time = (String) js1.get("event_time");
		String tags = js1.get("tags").toString();
		@SuppressWarnings("unused")
		SiteVisit s = new SiteVisit (key, event_time, customer_id, tags, c);
		//s.displayValue();
	}
	
	public static void upsertOrder (JSONObject js1)	{
		String customer_id = (String) js1.get("customer_id");
		Customer c = cust.get(customer_id);
		String key = (String) js1.get("key");
		String event_time = (String) js1.get("event_time");
		double total_amount = Double.parseDouble (((String) js1.get("total_amount")).replaceAll("[^0-9.]", ""));
		@SuppressWarnings("unused")
		Order o = new Order (key, event_time, customer_id, total_amount, c);
		//o.displayValue();
	}
	
	public static void insertImageUpload (JSONObject js1)	{
		String customer_id = (String) js1.get("customer_id");
		Customer c = cust.get(customer_id);
		String key = (String) js1.get("key");
		String event_time = (String) js1.get("event_time");
		String camera_make = (String) js1.get("camera_make");
		String camera_model = (String) js1.get("camera_model");
		@SuppressWarnings("unused")
		ImageUpload i = new ImageUpload (key, event_time, customer_id, camera_make, camera_model, c);
		//i.displayValue();
	}
	
	public static HashMap <String, Customer> Ingest (String event) throws IOException, ParseException, FileNotFoundException	{
		System.out.println("Ingesting Events File : " + event);
		JSONParser parser = new JSONParser();
		JSONObject jsonObject = (JSONObject) parser.parse(new FileReader(event));
		JSONArray jsonArray = (JSONArray)jsonObject.get("events");
		@SuppressWarnings("unchecked")
		Iterator<JSONObject> it = jsonArray.iterator();
		cust = new HashMap<String, Customer> ();
		while (it.hasNext())	{
			JSONObject jsonObject1 = it.next();
			String type = (String) jsonObject1.get("type");
			if (type.equals("CUSTOMER"))	upsertCustomer(jsonObject1);
			if (type.equals("SITE_VISIT"))	insertSiteVisit(jsonObject1);
			if (type.equals("IMAGE"))	insertImageUpload(jsonObject1);
			if (type.equals("ORDER"))	upsertOrder(jsonObject1);
		}
		return cust;
	}
}

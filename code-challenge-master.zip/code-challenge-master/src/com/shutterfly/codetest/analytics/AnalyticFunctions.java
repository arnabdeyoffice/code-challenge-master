package com.shutterfly.codetest.analytics;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.TreeSet;

import com.shutterfly.codetest.entity.*;
import com.shutterfly.codetest.metics.*;

public class AnalyticFunctions {
	
	public static double avg_visits_per_week_per_customer(Customer c)	{
		
		ArrayList <SiteVisit> sv = (ArrayList<SiteVisit>) c.getSiteVisits();
		String max_date = "0001-01-01";
		String min_date = "9999-12-31";
		int visit_count=sv.size();
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		int visit_weeks=0;
		
		for (int i=0; i<sv.size(); i++)	{
			String date_part = sv.get(i).getEventTime().substring(0,10);
			if (date_part.compareTo(max_date) > 0)		max_date = date_part;
			if (date_part.compareTo(min_date) < 0)		min_date = date_part;
		}
		
		try {
			Calendar max_dt = Calendar.getInstance();
			max_dt.setTime(df.parse(max_date));
			Calendar min_dt = Calendar.getInstance();
			min_dt.setTime(df.parse(min_date));
			visit_weeks=(max_dt.get(Calendar.YEAR) - min_dt.get(Calendar.YEAR)) * 52 + 1 +
					(max_dt.get(Calendar.WEEK_OF_YEAR) - min_dt.get(Calendar.WEEK_OF_YEAR));
		} catch (ParseException e) {
		}
		
		//System.out.println(visit_count+" "+visit_weeks);
		
		return (double)visit_count / (double)visit_weeks;
	}
	
	public static double avg_revenue_per_visit_per_customer (Customer c)	{
		HashMap <String, Order> ord = c.getOrders();
		double total_revenue=0;
		for (String x: ord.keySet())	{
			total_revenue+=ord.get(x).getTotalAmount();
		}
		return total_revenue/ord.size();
	}
	
	public static double findSimpleLTV (Customer c)	{
		return 52 * (avg_visits_per_week_per_customer(c) * avg_revenue_per_visit_per_customer(c)) * 10;
	}
	
	public static ArrayList<CustomerLTV> TopXSimpleLTVCustomers(int x, HashMap<String, Customer> D)	{
		TreeSet<CustomerLTV> ts = new TreeSet<CustomerLTV> ();
		ArrayList<CustomerLTV> result = new ArrayList<CustomerLTV>();
		Iterator<String> it = D.keySet().iterator();
		while (it.hasNext())	{
			String cust=it.next();
			CustomerLTV cl = new CustomerLTV (cust, findSimpleLTV(D.get(cust)));
			ts.add(cl);
			if (ts.size() > x) 
				ts.pollLast();
		}
		Iterator<CustomerLTV> it1 = ts.iterator();
		while (it1.hasNext())	{
			CustomerLTV cl = it1.next();
			result.add(cl);
		}
		return result;
	}

}

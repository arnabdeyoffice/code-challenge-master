package com.shutterfly.codetest.code;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
//import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.HashMap;
import java.util.Iterator;

//import org.json.JSONException;
import org.json.simple.parser.ParseException;

import com.shutterfly.codetest.entity.*;
import com.shutterfly.codetest.metics.*;
import com.shutterfly.codetest.analytics.*;

public class TestMain {
	
	static HashMap <String, Customer> cust = null;
	
	@SuppressWarnings("unused")
	public static void main (String[] args) throws IOException, ParseException	{
		
		Customer c1,c2,c3; SiteVisit s1,s2,s3; ; Order o1,o2,o3;
		
		c1 = new Customer ("1234","2014-10-21 00:00:00","Dey","Phoenix","AZ");	
		s1 = new SiteVisit ("110","2014-12-23 00:00:00","1234","[{\"a\":\"b\"},{\"c\":\"d\"}]",c1);
		s1 = new SiteVisit ("111","2014-12-21 00:00:00","1234","[{\"a\":\"b\"},{\"c\":\"d\"}]",c1);
		s1 = new SiteVisit ("112","2014-12-03 00:00:00","1234","[{\"a\":\"b\"},{\"c\":\"d\"}]",c1);
		s1 = new SiteVisit ("113","2015-01-20 00:00:00","1234","[{\"a\":\"b\"},{\"c\":\"d\"}]",c1);
		o1 = new Order ("210","2014-12-23 00:00:00","1234",30.14,c1);
		o1 = new Order ("211","2014-12-21 00:00:00","1234",30.24,c1);
		o1 = new Order ("212","2014-12-03 00:00:00","1234",50.14,c1);
		o1 = new Order ("213","2015-01-20 00:00:00","1234",12.34,c1);
		c2 = new Customer ("5678","2015-11-31 00:00:00","Ghosh","Phoenix","AZ");	
		s2 = new SiteVisit ("114","2015-12-23 00:00:00","5678","[{\"a\":\"b\"},{\"c\":\"d\"}]",c2);
		s2 = new SiteVisit ("115","2015-12-21 00:00:00","5678","[{\"a\":\"b\"},{\"c\":\"d\"}]",c2);
		s2 = new SiteVisit ("116","2015-12-03 00:00:00","5678","[{\"a\":\"b\"},{\"c\":\"d\"}]",c2);
		o2 = new Order ("214","2015-12-23 00:00:00","5678",12.14,c2);
		o2 = new Order ("215","2015-12-23 00:00:00","5678",14.24,c2);
		o2 = new Order ("216","2015-12-23 00:00:00","5678",23.14,c2);
		c3 = new Customer ("9101","2017-01-01 00:00:00","Dutta","BOS","MA");
		s3 = new SiteVisit ("117","2017-01-01 00:00:00","9101","[{\"a\":\"b\"},{\"c\":\"d\"}]",c3);
		s3 = new SiteVisit ("118","2017-01-02 00:00:00","9101","[{\"a\":\"b\"},{\"c\":\"d\"}]",c3);
		s3 = new SiteVisit ("119","2017-01-03 00:00:00","9101","[{\"a\":\"b\"},{\"c\":\"d\"}]",c3);
		o3 = new Order ("217","2017-01-01 00:00:00","9101",121.14,c3);
		o3 = new Order ("218","2017-01-02 00:00:00","9101",141.24,c3);
		o3 = new Order ("219","2017-01-03 00:00:00","9101",231.14,c3); 
		c1.update("1234","2014-10-21 00:00:00","Dey","SFO","CA");
		
		/*
		cust = IngestFunctions.Ingest("input/input.txt");
		
		*/
		
		cust=new HashMap<String, Customer>	();
		cust.put ("1234",c1);
		cust.put ("5678",c2);
		cust.put ("9101",c3);
		
		Iterator<String> it = cust.keySet().iterator();
		while (it.hasNext())	{
			cust.get(it.next()).displayString();
		}
		
		int line=0;
		File file = new File("output/test.txt");
		if (file.exists()) {
			file.delete();
		}
		FileOutputStream output = new FileOutputStream(file);
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(output));
				
		for (CustomerLTV cus : AnalyticFunctions.TopXSimpleLTVCustomers(2,cust))	{
			line++;
			bw.write(String.format("%d. Customer : %s LTV : %.2f\n",line,cus.getCustomer(),cus.getLTV()));
		}
		
		bw.close();
		
		/* 
		System.out.println(AnalyticFunctions.avg_visits_per_week_per_customer(cust.get("1234")));
		System.out.println(AnalyticFunctions.avg_revenue_per_visit_per_customer(cust.get("1234")));
		System.out.println(AnalyticFunctions.findSimpleLTV(cust.get("1234")));
		
		System.out.println(AnalyticFunctions.avg_visits_per_week_per_customer(cust.get("5678")));
		System.out.println(AnalyticFunctions.avg_revenue_per_visit_per_customer(cust.get("5678")));
		System.out.println(AnalyticFunctions.findSimpleLTV(cust.get("5678")));
		
		System.out.println(AnalyticFunctions.avg_visits_per_week_per_customer(cust.get("9101")));
		System.out.println(AnalyticFunctions.avg_revenue_per_visit_per_customer(cust.get("9101")));
		System.out.println(AnalyticFunctions.findSimpleLTV(cust.get("9101")));
		
		*/
	}
}

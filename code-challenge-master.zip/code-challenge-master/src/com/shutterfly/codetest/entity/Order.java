package com.shutterfly.codetest.entity;

public class Order {
	String key, event_time, customer_id; double total_amount;
	
	public Order (String key, String event_time, String customer_id, double total_amount, Customer c)	{
		this.key=key;
		this.event_time=event_time;
		this.customer_id=customer_id;
		this.total_amount=total_amount;
		c.addOrder(key, this);
	}
	
	public double getTotalAmount ()	{
		return this.total_amount;
	}
	
	public void displayKey ()	{
		System.out.println ("  Order Key : " + this.key);
	}

	public void displayValue ()	{
		System.out.printf("  Order Values : %s %s %s %f\n",this.key,this.event_time,this.customer_id,this.total_amount);
	}
	
}

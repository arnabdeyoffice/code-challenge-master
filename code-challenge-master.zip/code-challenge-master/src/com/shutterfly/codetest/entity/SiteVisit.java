package com.shutterfly.codetest.entity;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.json.JSONArray;
//import org.json.JSONObject;

public class SiteVisit {
	
	String key, event_time, customer_id;
	Map<String, String> tags;
	
	public SiteVisit (String key, String event_time, String customer_id, String tags, Customer c)	{
		this.key=key;
		this.event_time=event_time;
		this.customer_id=customer_id;
		this.tags = new HashMap<String, String> ();
		//System.out.println(tags);
		JSONArray jsonArray = new JSONArray(tags);
		for(int i=0;i<jsonArray.length();i++)	{
			JSONArray js1 = jsonArray.getJSONObject(i).names();
			String key1 = (String) js1.get(0);
			String value1 = jsonArray.getJSONObject(i).optString(key1);
			this.tags.put(key1,value1);
		}
		c.addSiteVisit(this);
	}
	
	public String getEventTime()	{
		return this.event_time;
	}
	
	public void displayKey ()	{
		System.out.println("  Site Visit Key " + this.key);
	}
	
	public void displayValue ()	{
		System.out.printf("  Site Visit Values : %s %s %s\n",this.key,this.event_time,this.customer_id);
		System.out.print ("  Tags : ");
		Iterator <String> it = this.tags.keySet().iterator();
		while (it.hasNext())	{
			String k1 = it.next();
			System.out.print (k1 + " : " + this.tags.get(k1) + ", ");
		}
		System.out.println();
	}
	
}

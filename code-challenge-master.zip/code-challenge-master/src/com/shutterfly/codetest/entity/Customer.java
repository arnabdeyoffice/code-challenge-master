package com.shutterfly.codetest.entity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Customer {
	
	String key, event_time, last_name, adr_city, adr_state;
	List <SiteVisit> sv = null;
	List <ImageUpload> iu = null;
	HashMap <String, Order> ord = null;
	
	public Customer (String key, String event_time, String last_name, String adr_city, String adr_state)	{
		this.key=key;
		this.event_time=event_time;
		this.last_name=last_name;
		this.adr_city=adr_city;
		this.adr_state=adr_state;
		sv = new ArrayList <SiteVisit> ();
		iu = new ArrayList <ImageUpload> ();	
		ord = new HashMap <String, Order> ();
	}
	
	public void update (String key, String event_time, String last_name, String adr_city, String adr_state)	{
		this.key=key;
		this.event_time=event_time;
		this.last_name=last_name;
		this.adr_city=adr_city;
		this.adr_state=adr_state;
	}
	
	public void addSiteVisit (SiteVisit sv1)	{
		this.sv.add(sv1);
	}
	
	public List <SiteVisit> getSiteVisits ()	{
		return this.sv;
	}
	
	public void addImageUpload (ImageUpload iu1)	{
		this.iu.add(iu1);
	}
	
	public List <ImageUpload> getImageUploads ()	{
		return this.iu;
	}
	
	public void addOrder (String key, Order ord1)	{
		if (this.ord.containsKey(key))	this.ord.remove(key);
		this.ord.put(key, ord1);
	}
	
	public HashMap <String, Order> getOrders ()	{
		return this.ord;
	}	
	
	public void displayString ()	{
		System.out.println("Customer Object : key - " + this.key + ", event_time - " + this.event_time 
				+ ", last_name - " + this.last_name + ", adr_city - "
				+ this.adr_city + ", adr_state - " + this.adr_state);
		System.out.println(" Child Site Visits : ");
		for (int i = 0; i < sv.size(); i++)	{
			this.sv.get(i).displayKey();
		}
		System.out.println(" Child Image Uploads : ");
		for (int i = 0; i < iu.size(); i++)	{
			this.iu.get(i).displayKey();
		}
		System.out.println(" Child Orders : ");
		for (Map.Entry<String, Order> entry : this.ord.entrySet())	{
			entry.getValue().displayKey();
		}
	}
	
}

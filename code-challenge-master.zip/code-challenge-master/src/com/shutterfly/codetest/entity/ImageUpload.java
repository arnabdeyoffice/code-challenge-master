package com.shutterfly.codetest.entity;

public class ImageUpload {
	
	String key, event_time, customer_id, camera_make, camera_model;
	
	public ImageUpload (String key, String event_time, String customer_id, String camera_make, String camera_model, Customer c)	{
		this.key=key;
		this.event_time=event_time;
		this.customer_id=customer_id;
		this.camera_make=camera_make;
		this.camera_model=camera_model;
		c.addImageUpload(this);
	}
	
	public void displayKey ()	{
		System.out.println ("  Image Upload Key : " + this.key);
	}
	
	public void displayValue ()	{
		System.out.printf("  Image Upload Values : %s %s %s %s %s\n",this.key,this.event_time,this.customer_id,
				this.camera_make, this.camera_model);
	}
	
}

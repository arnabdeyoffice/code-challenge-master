package com.shutterfly.codetest.metics;

public class CustomerLTV implements Comparable <CustomerLTV>{

	String cust;
	double ltv;
	
	public CustomerLTV (String cust1, double ltv1)	{
		cust=cust1;
		ltv=ltv1;
	}
	
	public String getCustomer ()	{
		return cust;
	}
	
	public double getLTV ()	{
		return ltv;
	}
	
	public int compareTo(CustomerLTV o) {
		if (this.ltv < o.ltv)	return 1;
		if (this.ltv > o.ltv)	return -1;
		else return 0;
	}
	
}
